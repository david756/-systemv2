--
-- Database: `sistema`
--

-- --------------------------------------------------------

--
-- Table structure for table `accion_inventarios`
--

CREATE TABLE `accion_inventarios` (
  `id` int(10) NOT NULL,
  `descripcion` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accion_inventarios`
--

INSERT INTO `accion_inventarios` (`id`, `descripcion`) VALUES
(1, 'Agregar'),
(2, 'Eliminar');

-- --------------------------------------------------------

--
-- Table structure for table `atenciones`
--

CREATE TABLE `atenciones` (
  `id` int(10) NOT NULL,
  `descripcion_estado` varchar(50) DEFAULT NULL,
  `descuento` int(10) DEFAULT NULL,
  `fk_estado` int(10) NOT NULL,
  `fk_mesa` int(10) NOT NULL,
  `fk_cajero` int(10) DEFAULT NULL,
  `horaPago` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `atencion_empleados`
--

CREATE TABLE `atencion_empleados` (
  `id` int(10) NOT NULL,
  `fk_usuario` int(10) NOT NULL,
  `fk_item` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `categorias`
--

CREATE TABLE `categorias` (
  `id` int(10) NOT NULL,
  `nombre` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categorias`
--

INSERT INTO `categorias` (`id`, `nombre`) VALUES
(28, 'Jugos'),
(30, 'licor'),
(31, 'comidas');

-- --------------------------------------------------------

--
-- Table structure for table `estados_atencion`
--

CREATE TABLE `estados_atencion` (
  `id` int(10) NOT NULL,
  `descripcion` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `estados_atencion`
--

INSERT INTO `estados_atencion` (`id`, `descripcion`) VALUES
(1, 'pedido'),
(2, 'pago'),
(3, 'cortesia'),
(4, 'aplazado');

-- --------------------------------------------------------

--
-- Table structure for table `estado_items`
--

CREATE TABLE `estado_items` (
  `id` int(10) NOT NULL,
  `descripcion` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `estado_items`
--

INSERT INTO `estado_items` (`id`, `descripcion`) VALUES
(1, 'pedido'),
(2, 'preparando'),
(3, 'despachado');

-- --------------------------------------------------------

--
-- Table structure for table `estado_mesas`
--

CREATE TABLE `estado_mesas` (
  `id` int(10) NOT NULL,
  `descripcion` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `estado_mesas`
--

INSERT INTO `estado_mesas` (`id`, `descripcion`) VALUES
(1, 'activa'),
(2, 'bloqueada');

-- --------------------------------------------------------

--
-- Table structure for table `estado_productos`
--

CREATE TABLE `estado_productos` (
  `id` int(10) NOT NULL,
  `descripcion` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `estado_productos`
--

INSERT INTO `estado_productos` (`id`, `descripcion`) VALUES
(1, 'activo'),
(2, 'bloqueado');

-- --------------------------------------------------------

--
-- Table structure for table `estado_usuarios`
--

CREATE TABLE `estado_usuarios` (
  `id` int(10) NOT NULL,
  `descripcion` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `estado_usuarios`
--

INSERT INTO `estado_usuarios` (`id`, `descripcion`) VALUES
(1, 'activo'),
(2, 'bloqueado');

-- --------------------------------------------------------

--
-- Table structure for table `inventarios`
--

CREATE TABLE `inventarios` (
  `id` int(10) NOT NULL,
  `fecha` datetime NOT NULL,
  `cantidad` int(10) NOT NULL,
  `proveedor` varchar(25) DEFAULT NULL,
  `costo` int(10) DEFAULT NULL,
  `descripcion` varchar(200) NOT NULL,
  `fk_producto` int(10) NOT NULL,
  `fk_accion` int(10) NOT NULL,
  `fk_empleado` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `id` int(10) NOT NULL,
  `valor` int(10) DEFAULT NULL,
  `anexos` varchar(60) DEFAULT NULL,
  `hora_pedido` datetime DEFAULT NULL,
  `hora_preparacion` datetime DEFAULT NULL,
  `hora_despacho` datetime DEFAULT NULL,
  `fk_atencion` int(10) NOT NULL,
  `fk_producto` int(10) NOT NULL,
  `fk_estado_item` int(10) NOT NULL,
  `fk_cocinero` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `mesas`
--

CREATE TABLE `mesas` (
  `id` int(10) NOT NULL,
  `descripcion` varchar(100) NOT NULL,
  `fk_estado` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mesas`
--

INSERT INTO `mesas` (`id`, `descripcion`, `fk_estado`) VALUES
(31, 'Mesa 1', 1),
(47, 'Mesa 2', 1);

-- --------------------------------------------------------

--
-- Table structure for table `notificaciones`
--

CREATE TABLE `notificaciones` (
  `id` int(10) NOT NULL,
  `mensaje` varchar(300) NOT NULL,
  `fecha` datetime NOT NULL,
  `fk_destino` int(10) NOT NULL,
  `fk_usuario` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notificaciones`
--

INSERT INTO `notificaciones` (`id`, `mensaje`, `fecha`, `fk_destino`, `fk_usuario`) VALUES
(10, 'david realizo un pedido', '2016-07-25 18:08:20', 206, 206);

-- --------------------------------------------------------

--
-- Table structure for table `perfiles`
--

CREATE TABLE `perfiles` (
  `id` int(10) NOT NULL,
  `descripcion` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `perfiles`
--

INSERT INTO `perfiles` (`id`, `descripcion`) VALUES
(1, 'Cajero'),
(2, 'Mesero'),
(3, 'Cocinero'),
(4, 'inventario');

-- --------------------------------------------------------

--
-- Table structure for table `perfil_empleados`
--

CREATE TABLE `perfil_empleados` (
  `id` int(10) NOT NULL,
  `fk_perfil` int(10) NOT NULL,
  `fk_empleado` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `perfil_empleados`
--

INSERT INTO `perfil_empleados` (`id`, `fk_perfil`, `fk_empleado`) VALUES
(244, 1, 207);

-- --------------------------------------------------------

--
-- Table structure for table `productos`
--

CREATE TABLE `productos` (
  `id` int(10) NOT NULL,
  `nombre` varchar(25) NOT NULL,
  `valor` int(20) NOT NULL,
  `descripcion` varchar(300) NOT NULL,
  `fk_estado` int(10) NOT NULL,
  `fk_categoria` int(10) NOT NULL,
  `control_stock` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `productos`
--

INSERT INTO `productos` (`id`, `nombre`, `valor`, `descripcion`, `fk_estado`, `fk_categoria`, `control_stock`) VALUES
(41, 'cerveza Poker', 2500, 'Cerveza poker 250 ml', 1, 30, 1);

-- --------------------------------------------------------

--
-- Table structure for table `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(10) NOT NULL,
  `nombre` varchar(20) NOT NULL,
  `apellido` varchar(20) DEFAULT NULL,
  `telefono` varchar(20) NOT NULL,
  `genero` varchar(20) NOT NULL,
  `usuario` varchar(10) NOT NULL,
  `clave` varchar(10) NOT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `fk_estado` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `apellido`, `telefono`, `genero`, `usuario`, `clave`, `admin`, `fk_estado`) VALUES
(206, 'david', 'Hernandez', '3113142928', 'M', 'david', 'david', 1, 1),
(207, 'Juan', 'Cardona', '7584895', 'M', 'juan', 'juan1', 0, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accion_inventarios`
--
ALTER TABLE `accion_inventarios`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `atenciones`
--
ALTER TABLE `atenciones`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_estado` (`fk_estado`),
  ADD KEY `fk_mesa` (`fk_mesa`),
  ADD KEY `fk_cajero` (`fk_cajero`);

--
-- Indexes for table `atencion_empleados`
--
ALTER TABLE `atencion_empleados`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_empleado` (`fk_usuario`),
  ADD KEY `fk_aten_prod` (`fk_item`),
  ADD KEY `fk_aten_prod_2` (`fk_item`);

--
-- Indexes for table `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `estados_atencion`
--
ALTER TABLE `estados_atencion`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `estado_items`
--
ALTER TABLE `estado_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `estado_mesas`
--
ALTER TABLE `estado_mesas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `estado_productos`
--
ALTER TABLE `estado_productos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `estado_usuarios`
--
ALTER TABLE `estado_usuarios`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inventarios`
--
ALTER TABLE `inventarios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_producto` (`fk_producto`),
  ADD KEY `fk_accion` (`fk_accion`),
  ADD KEY `fk_empleado` (`fk_empleado`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_atencion` (`fk_atencion`,`fk_producto`),
  ADD KEY `fk_producto` (`fk_producto`),
  ADD KEY `fk_estadoProd` (`fk_estado_item`),
  ADD KEY `fk_cocinero` (`fk_cocinero`);

--
-- Indexes for table `mesas`
--
ALTER TABLE `mesas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_estado` (`fk_estado`);

--
-- Indexes for table `notificaciones`
--
ALTER TABLE `notificaciones`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_usuario` (`fk_usuario`),
  ADD KEY `fk_destino` (`fk_destino`);

--
-- Indexes for table `perfiles`
--
ALTER TABLE `perfiles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `perfil_empleados`
--
ALTER TABLE `perfil_empleados`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_perfil` (`fk_perfil`),
  ADD KEY `fk_empleado` (`fk_empleado`);

--
-- Indexes for table `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_categoria` (`fk_categoria`),
  ADD KEY `fk_estado` (`fk_estado`);

--
-- Indexes for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_estado` (`fk_estado`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accion_inventarios`
--
ALTER TABLE `accion_inventarios`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `atenciones`
--
ALTER TABLE `atenciones`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=991982;
--
-- AUTO_INCREMENT for table `atencion_empleados`
--
ALTER TABLE `atencion_empleados`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT for table `estados_atencion`
--
ALTER TABLE `estados_atencion`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `estado_items`
--
ALTER TABLE `estado_items`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `estado_mesas`
--
ALTER TABLE `estado_mesas`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `estado_productos`
--
ALTER TABLE `estado_productos`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `estado_usuarios`
--
ALTER TABLE `estado_usuarios`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `inventarios`
--
ALTER TABLE `inventarios`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `mesas`
--
ALTER TABLE `mesas`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;
--
-- AUTO_INCREMENT for table `notificaciones`
--
ALTER TABLE `notificaciones`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `perfiles`
--
ALTER TABLE `perfiles`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `perfil_empleados`
--
ALTER TABLE `perfil_empleados`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=245;
--
-- AUTO_INCREMENT for table `productos`
--
ALTER TABLE `productos`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;
--
-- AUTO_INCREMENT for table `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=208;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `atenciones`
--
ALTER TABLE `atenciones`
  ADD CONSTRAINT `atenciones_ibfk_4` FOREIGN KEY (`fk_cajero`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  ADD CONSTRAINT `atenciones_ibfk_5` FOREIGN KEY (`fk_mesa`) REFERENCES `mesas` (`id`),
  ADD CONSTRAINT `atenciones_ibfk_6` FOREIGN KEY (`fk_estado`) REFERENCES `estados_atencion` (`id`);

--
-- Constraints for table `inventarios`
--
ALTER TABLE `inventarios`
  ADD CONSTRAINT `inventarios_ibfk_1` FOREIGN KEY (`fk_producto`) REFERENCES `productos` (`id`),
  ADD CONSTRAINT `inventarios_ibfk_2` FOREIGN KEY (`fk_accion`) REFERENCES `accion_inventarios` (`id`),
  ADD CONSTRAINT `inventarios_ibfk_3` FOREIGN KEY (`fk_empleado`) REFERENCES `usuarios` (`id`);

--
-- Constraints for table `items`
--
ALTER TABLE `items`
  ADD CONSTRAINT `items_ibfk_4` FOREIGN KEY (`fk_cocinero`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `items_ibfk_5` FOREIGN KEY (`fk_atencion`) REFERENCES `atenciones` (`id`),
  ADD CONSTRAINT `items_ibfk_6` FOREIGN KEY (`fk_producto`) REFERENCES `productos` (`id`),
  ADD CONSTRAINT `items_ibfk_7` FOREIGN KEY (`fk_estado_item`) REFERENCES `estado_items` (`id`);

--
-- Constraints for table `mesas`
--
ALTER TABLE `mesas`
  ADD CONSTRAINT `mesas_ibfk_1` FOREIGN KEY (`fk_estado`) REFERENCES `estado_mesas` (`id`);

--
-- Constraints for table `notificaciones`
--
ALTER TABLE `notificaciones`
  ADD CONSTRAINT `notificaciones_ibfk_1` FOREIGN KEY (`fk_usuario`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `notificaciones_ibfk_2` FOREIGN KEY (`fk_destino`) REFERENCES `usuarios` (`id`);

--
-- Constraints for table `perfil_empleados`
--
ALTER TABLE `perfil_empleados`
  ADD CONSTRAINT `perfil_empleados_ibfk_1` FOREIGN KEY (`fk_empleado`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `perfil_empleados_ibfk_2` FOREIGN KEY (`fk_perfil`) REFERENCES `perfiles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `productos`
--
ALTER TABLE `productos`
  ADD CONSTRAINT `productos_ibfk_1` FOREIGN KEY (`fk_categoria`) REFERENCES `categorias` (`id`),
  ADD CONSTRAINT `productos_ibfk_2` FOREIGN KEY (`fk_estado`) REFERENCES `estado_productos` (`id`);

--
-- Constraints for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`fk_estado`) REFERENCES `estado_usuarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
