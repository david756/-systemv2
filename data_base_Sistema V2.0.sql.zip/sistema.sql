--
-- Base de datos: `sistema`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `accion_inventarios`
--

CREATE TABLE `accion_inventarios` (
  `id` int(10) NOT NULL,
  `descripcion` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `accion_inventarios`
--

INSERT INTO `accion_inventarios` (`id`, `descripcion`) VALUES
(1, 'Agregar'),
(2, 'Eliminar');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `atenciones`
--

CREATE TABLE `atenciones` (
  `id` int(10) NOT NULL,
  `descripcion_estado` varchar(50) DEFAULT NULL,
  `descuento` int(10) DEFAULT NULL,
  `fk_estado` int(10) DEFAULT NULL,
  `fk_mesa` int(10) DEFAULT NULL,
  `fk_cajero` int(10) DEFAULT NULL,
  `horaPago` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `atenciones`
--

INSERT INTO `atenciones` (`id`, `descripcion_estado`, `descuento`, `fk_estado`, `fk_mesa`, `fk_cajero`, `horaPago`) VALUES
(991980, 'descripcion del estado', 5000, 1, 31, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `atencion_empleados`
--

CREATE TABLE `atencion_empleados` (
  `id` int(10) NOT NULL,
  `fk_usuario` int(10) DEFAULT NULL,
  `fk_item` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `id` int(10) NOT NULL,
  `nombre` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id`, `nombre`) VALUES
(28, 'categoria2');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estados_atencion`
--

CREATE TABLE `estados_atencion` (
  `id` int(10) NOT NULL,
  `descripcion` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `estados_atencion`
--

INSERT INTO `estados_atencion` (`id`, `descripcion`) VALUES
(1, 'pedido'),
(2, 'pago'),
(3, 'cortesia'),
(4, 'aplazado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado_items`
--

CREATE TABLE `estado_items` (
  `id` int(10) NOT NULL,
  `descripcion` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `estado_items`
--

INSERT INTO `estado_items` (`id`, `descripcion`) VALUES
(1, 'pedido'),
(2, 'preparando'),
(3, 'despachado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado_mesas`
--

CREATE TABLE `estado_mesas` (
  `id` int(10) NOT NULL,
  `descripcion` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `estado_mesas`
--

INSERT INTO `estado_mesas` (`id`, `descripcion`) VALUES
(1, 'activa'),
(2, 'bloqueada');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado_productos`
--

CREATE TABLE `estado_productos` (
  `id` int(10) NOT NULL,
  `descripcion` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `estado_productos`
--

INSERT INTO `estado_productos` (`id`, `descripcion`) VALUES
(1, 'activo'),
(2, 'bloqueado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado_usuarios`
--

CREATE TABLE `estado_usuarios` (
  `id` int(10) NOT NULL,
  `descripcion` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `estado_usuarios`
--

INSERT INTO `estado_usuarios` (`id`, `descripcion`) VALUES
(1, 'activo'),
(2, 'bloqueado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inventarios`
--

CREATE TABLE `inventarios` (
  `id` int(10) NOT NULL,
  `fecha` datetime NOT NULL,
  `cantidad` int(10) NOT NULL,
  `proveedor` varchar(25) DEFAULT NULL,
  `costo` int(10) DEFAULT NULL,
  `descripcion` varchar(200) NOT NULL,
  `fk_producto` int(10) DEFAULT NULL,
  `fk_accion` int(10) DEFAULT NULL,
  `fk_empleado` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `items`
--

CREATE TABLE `items` (
  `id` int(10) NOT NULL,
  `valor` int(10) DEFAULT NULL,
  `anexos` varchar(60) DEFAULT NULL,
  `hora_pedido` datetime DEFAULT NULL,
  `hora_preparacion` datetime DEFAULT NULL,
  `hora_despacho` datetime DEFAULT NULL,
  `fk_atencion` int(10) DEFAULT NULL,
  `fk_producto` int(10) DEFAULT NULL,
  `fk_estado_item` int(10) DEFAULT NULL,
  `fk_cocinero` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mesas`
--

CREATE TABLE `mesas` (
  `id` int(10) NOT NULL,
  `descripcion` varchar(100) NOT NULL,
  `fk_estado` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `mesas`
--

INSERT INTO `mesas` (`id`, `descripcion`, `fk_estado`) VALUES
(31, 'Mesa 2', 1),
(45, 'mesa 3', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notificaciones`
--

CREATE TABLE `notificaciones` (
  `id` int(10) NOT NULL,
  `mensaje` varchar(200) NOT NULL,
  `fecha` datetime NOT NULL,
  `fk_destino` int(10) NOT NULL,
  `fk_usuario` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `notificaciones`
--

INSERT INTO `notificaciones` (`id`, `mensaje`, `fecha`, `fk_destino`, `fk_usuario`) VALUES
(2, 'nueva', '2016-07-12 14:29:20', 149, 150),
(3, 'mensaje de la notificacion para el usuario este', '2016-07-15 18:47:29', 149, 150),
(4, 'notinuevba de otro user', '2016-07-17 09:28:36', 149, 149),
(6, '', '0000-00-00 00:00:00', 149, 149),
(7, 'hola que hace', '0000-00-00 00:00:00', 149, 149),
(8, 'esta es la buena', '2016-07-17 20:42:12', 149, 149);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `perfiles`
--

CREATE TABLE `perfiles` (
  `id` int(10) NOT NULL,
  `descripcion` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `perfiles`
--

INSERT INTO `perfiles` (`id`, `descripcion`) VALUES
(1, 'Cajero'),
(2, 'Mesero'),
(3, 'Cocinero'),
(4, 'inventario');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `perfil_empleados`
--

CREATE TABLE `perfil_empleados` (
  `id` int(10) NOT NULL,
  `fk_perfil` int(10) NOT NULL,
  `fk_empleado` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `perfil_empleados`
--

INSERT INTO `perfil_empleados` (`id`, `fk_perfil`, `fk_empleado`) VALUES
(157, 4, 149);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id` int(10) NOT NULL,
  `nombre` varchar(25) NOT NULL,
  `valor` int(20) NOT NULL,
  `descripcion` varchar(300) NOT NULL,
  `fk_estado` int(10) NOT NULL,
  `fk_categoria` int(10) DEFAULT NULL,
  `control_stock` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id`, `nombre`, `valor`, `descripcion`, `fk_estado`, `fk_categoria`, `control_stock`) VALUES
(12, 'nombre', 10, 'descripcion', 1, 28, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(10) NOT NULL,
  `nombre` varchar(10) NOT NULL,
  `apellido` varchar(20) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `genero` varchar(20) DEFAULT NULL,
  `usuario` varchar(10) NOT NULL,
  `clave` varchar(10) NOT NULL,
  `admin` tinyint(1) DEFAULT NULL,
  `fk_estado` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `apellido`, `telefono`, `genero`, `usuario`, `clave`, `admin`, `fk_estado`) VALUES
(149, 'nombre', 'apellido', 'telefono', 'genero', 'usuario', 'pass', 1, 1),
(150, 'david', 'felipe', '3113142928', 'm', 'david1', '1234', 1, 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `accion_inventarios`
--
ALTER TABLE `accion_inventarios`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `atenciones`
--
ALTER TABLE `atenciones`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_estado` (`fk_estado`),
  ADD KEY `fk_mesa` (`fk_mesa`),
  ADD KEY `fk_cajero` (`fk_cajero`);

--
-- Indices de la tabla `atencion_empleados`
--
ALTER TABLE `atencion_empleados`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_empleado` (`fk_usuario`),
  ADD KEY `fk_aten_prod` (`fk_item`),
  ADD KEY `fk_aten_prod_2` (`fk_item`);

--
-- Indices de la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estados_atencion`
--
ALTER TABLE `estados_atencion`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estado_items`
--
ALTER TABLE `estado_items`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estado_mesas`
--
ALTER TABLE `estado_mesas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estado_productos`
--
ALTER TABLE `estado_productos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estado_usuarios`
--
ALTER TABLE `estado_usuarios`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `inventarios`
--
ALTER TABLE `inventarios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_producto` (`fk_producto`),
  ADD KEY `fk_accion` (`fk_accion`),
  ADD KEY `fk_empleado` (`fk_empleado`);

--
-- Indices de la tabla `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_atencion` (`fk_atencion`,`fk_producto`),
  ADD KEY `fk_producto` (`fk_producto`),
  ADD KEY `fk_estadoProd` (`fk_estado_item`),
  ADD KEY `fk_cocinero` (`fk_cocinero`);

--
-- Indices de la tabla `mesas`
--
ALTER TABLE `mesas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_estado` (`fk_estado`);

--
-- Indices de la tabla `notificaciones`
--
ALTER TABLE `notificaciones`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_usuario` (`fk_usuario`),
  ADD KEY `fk_destino` (`fk_destino`);

--
-- Indices de la tabla `perfiles`
--
ALTER TABLE `perfiles`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `perfil_empleados`
--
ALTER TABLE `perfil_empleados`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_perfil` (`fk_perfil`),
  ADD KEY `fk_empleado` (`fk_empleado`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_categoria` (`fk_categoria`),
  ADD KEY `fk_estado` (`fk_estado`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_estado` (`fk_estado`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `accion_inventarios`
--
ALTER TABLE `accion_inventarios`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `atenciones`
--
ALTER TABLE `atenciones`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=991981;
--
-- AUTO_INCREMENT de la tabla `atencion_empleados`
--
ALTER TABLE `atencion_empleados`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT de la tabla `estados_atencion`
--
ALTER TABLE `estados_atencion`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de la tabla `estado_items`
--
ALTER TABLE `estado_items`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de la tabla `estado_mesas`
--
ALTER TABLE `estado_mesas`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `estado_productos`
--
ALTER TABLE `estado_productos`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `estado_usuarios`
--
ALTER TABLE `estado_usuarios`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `inventarios`
--
ALTER TABLE `inventarios`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `items`
--
ALTER TABLE `items`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `mesas`
--
ALTER TABLE `mesas`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;
--
-- AUTO_INCREMENT de la tabla `notificaciones`
--
ALTER TABLE `notificaciones`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT de la tabla `perfiles`
--
ALTER TABLE `perfiles`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de la tabla `perfil_empleados`
--
ALTER TABLE `perfil_empleados`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=158;
--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=151;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `atenciones`
--
ALTER TABLE `atenciones`
  ADD CONSTRAINT `atenciones_ibfk_2` FOREIGN KEY (`fk_mesa`) REFERENCES `mesas` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  ADD CONSTRAINT `atenciones_ibfk_3` FOREIGN KEY (`fk_estado`) REFERENCES `estados_atencion` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  ADD CONSTRAINT `atenciones_ibfk_4` FOREIGN KEY (`fk_cajero`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL ON UPDATE SET NULL;

--
-- Filtros para la tabla `atencion_empleados`
--
ALTER TABLE `atencion_empleados`
  ADD CONSTRAINT `atencion_empleados_ibfk_1` FOREIGN KEY (`fk_usuario`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  ADD CONSTRAINT `atencion_empleados_ibfk_2` FOREIGN KEY (`fk_item`) REFERENCES `items` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `inventarios`
--
ALTER TABLE `inventarios`
  ADD CONSTRAINT `inventarios_ibfk_1` FOREIGN KEY (`fk_producto`) REFERENCES `productos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `inventarios_ibfk_2` FOREIGN KEY (`fk_accion`) REFERENCES `accion_inventarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `inventarios_ibfk_3` FOREIGN KEY (`fk_empleado`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Filtros para la tabla `items`
--
ALTER TABLE `items`
  ADD CONSTRAINT `items_ibfk_1` FOREIGN KEY (`fk_atencion`) REFERENCES `atenciones` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  ADD CONSTRAINT `items_ibfk_2` FOREIGN KEY (`fk_producto`) REFERENCES `productos` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  ADD CONSTRAINT `items_ibfk_3` FOREIGN KEY (`fk_estado_item`) REFERENCES `estado_items` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  ADD CONSTRAINT `items_ibfk_4` FOREIGN KEY (`fk_cocinero`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL ON UPDATE SET NULL;

--
-- Filtros para la tabla `mesas`
--
ALTER TABLE `mesas`
  ADD CONSTRAINT `mesas_ibfk_1` FOREIGN KEY (`fk_estado`) REFERENCES `estado_mesas` (`id`) ON DELETE SET NULL ON UPDATE SET NULL;

--
-- Filtros para la tabla `notificaciones`
--
ALTER TABLE `notificaciones`
  ADD CONSTRAINT `notificaciones_ibfk_1` FOREIGN KEY (`fk_usuario`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `notificaciones_ibfk_2` FOREIGN KEY (`fk_destino`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `perfil_empleados`
--
ALTER TABLE `perfil_empleados`
  ADD CONSTRAINT `perfil_empleados_ibfk_1` FOREIGN KEY (`fk_empleado`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `perfil_empleados_ibfk_2` FOREIGN KEY (`fk_perfil`) REFERENCES `perfiles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `productos`
--
ALTER TABLE `productos`
  ADD CONSTRAINT `productos_ibfk_1` FOREIGN KEY (`fk_categoria`) REFERENCES `categorias` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  ADD CONSTRAINT `productos_ibfk_2` FOREIGN KEY (`fk_estado`) REFERENCES `estado_productos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`fk_estado`) REFERENCES `estado_usuarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
