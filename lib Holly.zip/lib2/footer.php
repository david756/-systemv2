        <!-- footer content -->
        <footer>
          <div class="copyright-info">
            <p class="pull-right"> Sistema Para la gestion de restaurante </a>
            </p>
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->