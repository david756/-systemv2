--
-- Base de datos: `sistema`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `accion_inventarios`
--

CREATE TABLE `accion_inventarios` (
  `id` int(10) NOT NULL,
  `descripcion` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELACIONES PARA LA TABLA `accion_inventarios`:
--

--
-- Volcado de datos para la tabla `accion_inventarios`
--

INSERT INTO `accion_inventarios` (`id`, `descripcion`) VALUES
(1, 'Agregar'),
(2, 'Eliminar');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `atenciones`
--

CREATE TABLE `atenciones` (
  `id` int(10) NOT NULL,
  `descripcion_estado` varchar(50) DEFAULT NULL,
  `descuento` int(10) NOT NULL DEFAULT '0',
  `fk_estado` int(10) NOT NULL,
  `fk_mesa` int(10) NOT NULL,
  `fk_cajero` int(10) DEFAULT NULL,
  `horaPago` datetime DEFAULT NULL,
  `horaInicio` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELACIONES PARA LA TABLA `atenciones`:
--   `fk_cajero`
--       `usuarios` -> `id`
--   `fk_mesa`
--       `mesas` -> `id`
--   `fk_estado`
--       `estados_atencion` -> `id`
--

--
-- Volcado de datos para la tabla `atenciones`
--

INSERT INTO `atenciones` (`id`, `descripcion_estado`, `descuento`, `fk_estado`, `fk_mesa`, `fk_cajero`, `horaPago`, `horaInicio`) VALUES
(10, 'pedido', 0, 1, 50, NULL, NULL, '2017-06-13 08:40:07');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `atencion_empleados`
--

CREATE TABLE `atencion_empleados` (
  `id` int(10) NOT NULL,
  `fk_usuario` int(10) NOT NULL,
  `fk_item` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELACIONES PARA LA TABLA `atencion_empleados`:
--   `fk_usuario`
--       `usuarios` -> `id`
--   `fk_item`
--       `items` -> `id`
--

--
-- Volcado de datos para la tabla `atencion_empleados`
--

INSERT INTO `atencion_empleados` (`id`, `fk_usuario`, `fk_item`) VALUES
(35, 206, 35),
(36, 206, 36);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `id` int(10) NOT NULL,
  `nombre` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELACIONES PARA LA TABLA `categorias`:
--

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id`, `nombre`) VALUES
(28, 'Jugos'),
(30, 'licor'),
(31, 'comidas');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estados_atencion`
--

CREATE TABLE `estados_atencion` (
  `id` int(10) NOT NULL,
  `descripcion` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELACIONES PARA LA TABLA `estados_atencion`:
--

--
-- Volcado de datos para la tabla `estados_atencion`
--

INSERT INTO `estados_atencion` (`id`, `descripcion`) VALUES
(1, 'pedido'),
(2, 'pago'),
(3, 'cortesia'),
(4, 'aplazado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado_items`
--

CREATE TABLE `estado_items` (
  `id` int(10) NOT NULL,
  `descripcion` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELACIONES PARA LA TABLA `estado_items`:
--

--
-- Volcado de datos para la tabla `estado_items`
--

INSERT INTO `estado_items` (`id`, `descripcion`) VALUES
(1, 'pedido'),
(2, 'preparando'),
(3, 'despachado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado_mesas`
--

CREATE TABLE `estado_mesas` (
  `id` int(10) NOT NULL,
  `descripcion` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELACIONES PARA LA TABLA `estado_mesas`:
--

--
-- Volcado de datos para la tabla `estado_mesas`
--

INSERT INTO `estado_mesas` (`id`, `descripcion`) VALUES
(1, 'activa'),
(2, 'bloqueada');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado_productos`
--

CREATE TABLE `estado_productos` (
  `id` int(10) NOT NULL,
  `descripcion` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELACIONES PARA LA TABLA `estado_productos`:
--

--
-- Volcado de datos para la tabla `estado_productos`
--

INSERT INTO `estado_productos` (`id`, `descripcion`) VALUES
(1, 'activo'),
(2, 'bloqueado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado_usuarios`
--

CREATE TABLE `estado_usuarios` (
  `id` int(10) NOT NULL,
  `descripcion` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELACIONES PARA LA TABLA `estado_usuarios`:
--

--
-- Volcado de datos para la tabla `estado_usuarios`
--

INSERT INTO `estado_usuarios` (`id`, `descripcion`) VALUES
(1, 'activo'),
(2, 'bloqueado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inventarios`
--

CREATE TABLE `inventarios` (
  `id` int(10) NOT NULL,
  `fecha` datetime NOT NULL,
  `cantidad` int(10) NOT NULL,
  `proveedor` varchar(25) DEFAULT NULL,
  `costo` int(10) DEFAULT NULL,
  `descripcion` varchar(200) NOT NULL,
  `fk_producto` int(10) NOT NULL,
  `fk_accion` int(10) NOT NULL,
  `fk_empleado` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELACIONES PARA LA TABLA `inventarios`:
--   `fk_producto`
--       `productos` -> `id`
--   `fk_accion`
--       `accion_inventarios` -> `id`
--   `fk_empleado`
--       `usuarios` -> `id`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `items`
--

CREATE TABLE `items` (
  `id` int(10) NOT NULL,
  `valor` int(10) DEFAULT NULL,
  `anexos` varchar(60) DEFAULT NULL,
  `hora_pedido` datetime DEFAULT NULL,
  `hora_preparacion` datetime DEFAULT NULL,
  `hora_despacho` datetime DEFAULT NULL,
  `fk_atencion` int(10) NOT NULL,
  `fk_producto` int(10) NOT NULL,
  `fk_estado_item` int(10) NOT NULL,
  `fk_cocinero` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELACIONES PARA LA TABLA `items`:
--   `fk_cocinero`
--       `usuarios` -> `id`
--   `fk_atencion`
--       `atenciones` -> `id`
--   `fk_producto`
--       `productos` -> `id`
--   `fk_estado_item`
--       `estado_items` -> `id`
--

--
-- Volcado de datos para la tabla `items`
--

INSERT INTO `items` (`id`, `valor`, `anexos`, `hora_pedido`, `hora_preparacion`, `hora_despacho`, `fk_atencion`, `fk_producto`, `fk_estado_item`, `fk_cocinero`) VALUES
(35, 14000, '', '2017-06-13 08:40:07', NULL, NULL, 10, 43, 1, NULL),
(36, 2500, '', '2017-06-13 08:40:57', NULL, NULL, 10, 41, 1, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mesas`
--

CREATE TABLE `mesas` (
  `id` int(10) NOT NULL,
  `descripcion` varchar(100) NOT NULL,
  `fk_estado` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELACIONES PARA LA TABLA `mesas`:
--   `fk_estado`
--       `estado_mesas` -> `id`
--

--
-- Volcado de datos para la tabla `mesas`
--

INSERT INTO `mesas` (`id`, `descripcion`, `fk_estado`) VALUES
(47, 'Mesa 1', 1),
(48, 'Mesa 2', 1),
(50, 'Mesa 3', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notificaciones`
--

CREATE TABLE `notificaciones` (
  `id` int(10) NOT NULL,
  `mensaje` varchar(300) NOT NULL,
  `fecha` datetime NOT NULL,
  `fk_destino` int(10) NOT NULL,
  `fk_usuario` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELACIONES PARA LA TABLA `notificaciones`:
--   `fk_usuario`
--       `usuarios` -> `id`
--   `fk_destino`
--       `usuarios` -> `id`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `perfiles`
--

CREATE TABLE `perfiles` (
  `id` int(10) NOT NULL,
  `descripcion` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELACIONES PARA LA TABLA `perfiles`:
--

--
-- Volcado de datos para la tabla `perfiles`
--

INSERT INTO `perfiles` (`id`, `descripcion`) VALUES
(1, 'Cajero'),
(2, 'Mesero'),
(3, 'Cocinero'),
(4, 'inventario');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `perfil_empleados`
--

CREATE TABLE `perfil_empleados` (
  `id` int(10) NOT NULL,
  `fk_perfil` int(10) NOT NULL,
  `fk_empleado` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELACIONES PARA LA TABLA `perfil_empleados`:
--   `fk_empleado`
--       `usuarios` -> `id`
--   `fk_perfil`
--       `perfiles` -> `id`
--

--
-- Volcado de datos para la tabla `perfil_empleados`
--

INSERT INTO `perfil_empleados` (`id`, `fk_perfil`, `fk_empleado`) VALUES
(258, 1, 208),
(259, 2, 208),
(260, 3, 208),
(261, 4, 208);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id` int(10) NOT NULL,
  `nombre` varchar(25) NOT NULL,
  `valor` int(20) NOT NULL,
  `descripcion` varchar(300) NOT NULL,
  `fk_estado` int(10) NOT NULL,
  `fk_categoria` int(10) NOT NULL,
  `control_stock` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELACIONES PARA LA TABLA `productos`:
--   `fk_categoria`
--       `categorias` -> `id`
--   `fk_estado`
--       `estado_productos` -> `id`
--

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id`, `nombre`, `valor`, `descripcion`, `fk_estado`, `fk_categoria`, `control_stock`) VALUES
(41, 'cerveza Poker', 2500, 'Cerveza poker 250 ml', 1, 31, 1),
(42, 'Hamburguesa ', 7500, 'hamburguesa premium', 1, 31, 0),
(43, 'carne Asada', 14000, 'carne asada al carbon', 1, 31, 0),
(44, 'Jugo', 1500, 'Jugo delicioso de piÃ±a', 1, 28, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(10) NOT NULL,
  `nombre` varchar(20) NOT NULL,
  `apellido` varchar(20) DEFAULT NULL,
  `telefono` varchar(20) NOT NULL,
  `genero` varchar(20) NOT NULL,
  `usuario` varchar(10) NOT NULL,
  `clave` varchar(10) NOT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `fk_estado` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELACIONES PARA LA TABLA `usuarios`:
--   `fk_estado`
--       `estado_usuarios` -> `id`
--

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `apellido`, `telefono`, `genero`, `usuario`, `clave`, `admin`, `fk_estado`) VALUES
(206, 'david', 'Hernandez', '3113142928', 'M', 'david', 'david', 1, 1),
(208, 'juan D', 'Gomez', '1254874', 'M', 'juan', 'juan', 0, 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `accion_inventarios`
--
ALTER TABLE `accion_inventarios`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `atenciones`
--
ALTER TABLE `atenciones`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_estado` (`fk_estado`),
  ADD KEY `fk_mesa` (`fk_mesa`),
  ADD KEY `fk_cajero` (`fk_cajero`);

--
-- Indices de la tabla `atencion_empleados`
--
ALTER TABLE `atencion_empleados`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_empleado` (`fk_usuario`),
  ADD KEY `fk_aten_prod` (`fk_item`),
  ADD KEY `fk_aten_prod_2` (`fk_item`),
  ADD KEY `fk_usuario` (`fk_usuario`,`fk_item`);

--
-- Indices de la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estados_atencion`
--
ALTER TABLE `estados_atencion`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estado_items`
--
ALTER TABLE `estado_items`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estado_mesas`
--
ALTER TABLE `estado_mesas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estado_productos`
--
ALTER TABLE `estado_productos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `estado_usuarios`
--
ALTER TABLE `estado_usuarios`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `inventarios`
--
ALTER TABLE `inventarios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_producto` (`fk_producto`),
  ADD KEY `fk_accion` (`fk_accion`),
  ADD KEY `fk_empleado` (`fk_empleado`);

--
-- Indices de la tabla `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_atencion` (`fk_atencion`,`fk_producto`),
  ADD KEY `fk_producto` (`fk_producto`),
  ADD KEY `fk_estadoProd` (`fk_estado_item`),
  ADD KEY `fk_cocinero` (`fk_cocinero`);

--
-- Indices de la tabla `mesas`
--
ALTER TABLE `mesas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_estado` (`fk_estado`);

--
-- Indices de la tabla `notificaciones`
--
ALTER TABLE `notificaciones`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_usuario` (`fk_usuario`),
  ADD KEY `fk_destino` (`fk_destino`);

--
-- Indices de la tabla `perfiles`
--
ALTER TABLE `perfiles`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `perfil_empleados`
--
ALTER TABLE `perfil_empleados`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_perfil` (`fk_perfil`),
  ADD KEY `fk_empleado` (`fk_empleado`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_categoria` (`fk_categoria`),
  ADD KEY `fk_estado` (`fk_estado`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_estado` (`fk_estado`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `accion_inventarios`
--
ALTER TABLE `accion_inventarios`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `atenciones`
--
ALTER TABLE `atenciones`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT de la tabla `atencion_empleados`
--
ALTER TABLE `atencion_empleados`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
--
-- AUTO_INCREMENT de la tabla `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT de la tabla `estados_atencion`
--
ALTER TABLE `estados_atencion`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de la tabla `estado_items`
--
ALTER TABLE `estado_items`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de la tabla `estado_mesas`
--
ALTER TABLE `estado_mesas`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `estado_productos`
--
ALTER TABLE `estado_productos`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `estado_usuarios`
--
ALTER TABLE `estado_usuarios`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `inventarios`
--
ALTER TABLE `inventarios`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `items`
--
ALTER TABLE `items`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
--
-- AUTO_INCREMENT de la tabla `mesas`
--
ALTER TABLE `mesas`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
--
-- AUTO_INCREMENT de la tabla `notificaciones`
--
ALTER TABLE `notificaciones`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `perfiles`
--
ALTER TABLE `perfiles`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de la tabla `perfil_empleados`
--
ALTER TABLE `perfil_empleados`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=262;
--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;
--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=209;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `atenciones`
--
ALTER TABLE `atenciones`
  ADD CONSTRAINT `atenciones_ibfk_4` FOREIGN KEY (`fk_cajero`) REFERENCES `usuarios` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  ADD CONSTRAINT `atenciones_ibfk_5` FOREIGN KEY (`fk_mesa`) REFERENCES `mesas` (`id`),
  ADD CONSTRAINT `atenciones_ibfk_6` FOREIGN KEY (`fk_estado`) REFERENCES `estados_atencion` (`id`);

--
-- Filtros para la tabla `atencion_empleados`
--
ALTER TABLE `atencion_empleados`
  ADD CONSTRAINT `atencion_empleados_ibfk_1` FOREIGN KEY (`fk_usuario`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `atencion_empleados_ibfk_2` FOREIGN KEY (`fk_item`) REFERENCES `items` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `inventarios`
--
ALTER TABLE `inventarios`
  ADD CONSTRAINT `inventarios_ibfk_1` FOREIGN KEY (`fk_producto`) REFERENCES `productos` (`id`),
  ADD CONSTRAINT `inventarios_ibfk_2` FOREIGN KEY (`fk_accion`) REFERENCES `accion_inventarios` (`id`),
  ADD CONSTRAINT `inventarios_ibfk_3` FOREIGN KEY (`fk_empleado`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `items`
--
ALTER TABLE `items`
  ADD CONSTRAINT `items_ibfk_4` FOREIGN KEY (`fk_cocinero`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `items_ibfk_5` FOREIGN KEY (`fk_atencion`) REFERENCES `atenciones` (`id`),
  ADD CONSTRAINT `items_ibfk_6` FOREIGN KEY (`fk_producto`) REFERENCES `productos` (`id`),
  ADD CONSTRAINT `items_ibfk_7` FOREIGN KEY (`fk_estado_item`) REFERENCES `estado_items` (`id`);

--
-- Filtros para la tabla `mesas`
--
ALTER TABLE `mesas`
  ADD CONSTRAINT `mesas_ibfk_1` FOREIGN KEY (`fk_estado`) REFERENCES `estado_mesas` (`id`);

--
-- Filtros para la tabla `notificaciones`
--
ALTER TABLE `notificaciones`
  ADD CONSTRAINT `notificaciones_ibfk_1` FOREIGN KEY (`fk_usuario`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `notificaciones_ibfk_2` FOREIGN KEY (`fk_destino`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `perfil_empleados`
--
ALTER TABLE `perfil_empleados`
  ADD CONSTRAINT `perfil_empleados_ibfk_1` FOREIGN KEY (`fk_empleado`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `perfil_empleados_ibfk_2` FOREIGN KEY (`fk_perfil`) REFERENCES `perfiles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `productos`
--
ALTER TABLE `productos`
  ADD CONSTRAINT `productos_ibfk_1` FOREIGN KEY (`fk_categoria`) REFERENCES `categorias` (`id`),
  ADD CONSTRAINT `productos_ibfk_2` FOREIGN KEY (`fk_estado`) REFERENCES `estado_productos` (`id`);

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`fk_estado`) REFERENCES `estado_usuarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;


--
-- Metadatos
--
USE `phpmyadmin`;

--
-- Metadatos para accion_inventarios
--

--
-- Metadatos para atenciones
--

--
-- Metadatos para atencion_empleados
--

--
-- Metadatos para categorias
--

--
-- Metadatos para estados_atencion
--

--
-- Metadatos para estado_items
--

--
-- Metadatos para estado_mesas
--

--
-- Metadatos para estado_productos
--

--
-- Metadatos para estado_usuarios
--

--
-- Metadatos para inventarios
--

--
-- Metadatos para items
--

--
-- Metadatos para mesas
--

--
-- Metadatos para notificaciones
--

--
-- Metadatos para perfiles
--

--
-- Metadatos para perfil_empleados
--

--
-- Metadatos para productos
--

--
-- Metadatos para usuarios
--

--
-- Metadatos para sistema
--

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
