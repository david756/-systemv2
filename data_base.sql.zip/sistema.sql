--
-- Database: `sistema`
--

-- --------------------------------------------------------

--
-- Table structure for table `acciones`
--

CREATE TABLE `acciones` (
  `id` int(10) NOT NULL,
  `descripcion` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `acciones`
--

INSERT INTO `acciones` (`id`, `descripcion`) VALUES
(1, 'Inicio Actividad'),
(2, 'Finalizo Actividad');

-- --------------------------------------------------------

--
-- Table structure for table `accion_inventarios`
--

CREATE TABLE `accion_inventarios` (
  `id` int(10) NOT NULL,
  `descripcion` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accion_inventarios`
--

INSERT INTO `accion_inventarios` (`id`, `descripcion`) VALUES
(1, 'Agregar'),
(2, 'Eliminar');

-- --------------------------------------------------------

--
-- Table structure for table `atenciones`
--

CREATE TABLE `atenciones` (
  `id` int(10) NOT NULL,
  `descripcion_estado` varchar(50) DEFAULT NULL,
  `descuento` int(10) DEFAULT NULL,
  `fk_estado` int(10) DEFAULT NULL,
  `fk_mesa` int(10) DEFAULT NULL,
  `fk_cajero` int(10) DEFAULT NULL,
  `horaPago` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `atenciones`
--

INSERT INTO `atenciones` (`id`, `descripcion_estado`, `descuento`, `fk_estado`, `fk_mesa`, `fk_cajero`, `horaPago`) VALUES
(991969, NULL, 0, 1, 1, NULL, NULL),
(991970, NULL, 0, 1, 3, NULL, NULL),
(991971, NULL, 0, 1, 5, NULL, NULL),
(991972, NULL, 0, 1, 8, NULL, NULL),
(991973, NULL, 0, 1, 4, NULL, NULL),
(991974, NULL, 0, 1, 6, NULL, NULL),
(991975, NULL, 0, 1, 2, NULL, NULL),
(991976, NULL, 0, 1, 10, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `aten_prod`
--

CREATE TABLE `aten_prod` (
  `id` int(10) NOT NULL,
  `valor` int(10) DEFAULT NULL,
  `anexos` varchar(60) DEFAULT NULL,
  `hora_pedido` datetime DEFAULT NULL,
  `hora_preparacion` datetime DEFAULT NULL,
  `hora_despacho` datetime DEFAULT NULL,
  `descuento` int(12) DEFAULT NULL,
  `fk_atencion` int(10) DEFAULT NULL,
  `fk_producto` int(10) DEFAULT NULL,
  `fk_estadoProd` int(10) DEFAULT NULL,
  `fk_cocinero` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aten_prod`
--

INSERT INTO `aten_prod` (`id`, `valor`, `anexos`, `hora_pedido`, `hora_preparacion`, `hora_despacho`, `descuento`, `fk_atencion`, `fk_producto`, `fk_estadoProd`, `fk_cocinero`) VALUES
(99737898, 7500, NULL, '2016-04-21 16:29:29', '2016-04-23 20:46:17', '2016-04-23 20:53:17', 0, 991969, 1, 3, NULL),
(99737899, 7500, NULL, '2016-04-21 16:29:29', '2016-04-25 20:43:08', '2016-04-25 20:43:16', 0, 991969, 1, 3, NULL),
(99737900, 5000, NULL, '2016-04-21 17:12:11', '2016-04-25 20:43:57', '2016-04-25 20:44:43', 0, 991970, 2, 3, NULL),
(99737901, 12000, NULL, '2016-04-21 17:12:11', '2016-04-25 20:43:27', '2016-04-25 20:44:44', 0, 991970, 5, 3, NULL),
(99737902, 1200, NULL, '2016-04-21 17:13:43', '2016-04-25 20:43:40', '2016-04-25 20:44:46', 0, 991971, 10, 3, NULL),
(99737903, 10000, NULL, '2016-04-21 17:17:19', '2016-04-25 20:44:01', '2016-04-25 20:44:48', 0, 991972, 4, 3, NULL),
(99737904, 2000, NULL, '2016-04-25 20:45:18', '2016-04-25 22:22:05', '2016-04-25 22:22:35', 0, 991973, 3, 3, NULL),
(99737905, 7500, NULL, '2016-04-25 20:45:24', '2016-04-25 22:22:06', '2016-04-25 22:22:37', 0, 991974, 1, 3, NULL),
(99737906, 10000, NULL, '2016-04-25 20:45:25', '2016-04-25 22:22:14', '2016-04-25 22:22:36', 0, 991974, 4, 3, NULL),
(99737907, 7500, NULL, '2016-04-25 21:02:04', '2016-04-25 22:22:18', '2016-04-25 22:22:22', 0, 991975, 1, 3, NULL),
(99737908, 10000, NULL, '2016-04-25 21:02:04', '2016-04-25 22:22:20', '2016-04-25 22:22:37', 0, 991975, 4, 3, NULL),
(99737909, 7500, NULL, '2016-04-25 21:15:50', '2016-04-25 22:22:12', '2016-04-25 22:22:41', 0, 991976, 1, 3, NULL),
(99737910, 10000, NULL, '2016-04-25 21:15:51', '2016-04-25 22:22:11', '2016-04-25 22:22:43', 0, 991976, 4, 3, NULL),
(99737911, 12000, NULL, '2016-04-25 21:15:51', '2016-04-25 22:22:10', '2016-04-25 22:22:45', 0, 991976, NULL, 3, NULL),
(99737912, 7500, NULL, '2016-04-25 22:22:55', '2016-04-25 22:23:15', '2016-04-25 22:27:55', 0, 991969, 1, 3, NULL),
(99737913, 7500, NULL, '2016-04-25 22:22:55', '2016-04-25 22:23:20', '2016-05-11 18:55:49', 0, 991969, 1, 3, NULL),
(99737914, 10000, NULL, '2016-04-25 22:22:55', '2016-04-25 22:23:22', '2016-04-25 22:27:58', 0, 991969, 4, 3, NULL),
(99737915, 10000, NULL, '2016-04-25 22:22:56', '2016-04-25 22:23:38', '2016-05-11 18:55:58', 0, 991969, 4, 3, NULL),
(99737916, 10000, NULL, '2016-04-25 22:22:56', '2016-05-11 18:55:52', '2016-05-11 18:55:55', 0, 991969, 4, 3, NULL),
(99737917, 12000, NULL, '2016-04-25 22:22:56', '2016-04-25 22:23:41', '2016-05-11 18:55:56', 0, 991969, NULL, 3, NULL),
(99737918, 7500, NULL, '2016-05-11 18:57:02', '2016-05-11 18:57:09', '2016-05-11 18:57:27', 0, 991972, 1, 3, NULL),
(99737919, 12000, NULL, '2016-05-11 18:57:02', '2016-05-11 18:57:22', '2016-05-11 18:57:24', 0, 991972, NULL, 3, NULL),
(99737920, 7500, NULL, '2016-06-05 16:59:36', '2016-06-05 16:59:43', '2016-06-05 16:59:45', 0, 991976, 1, 3, NULL),
(99737921, 10000, NULL, '2016-06-05 16:59:37', '2016-06-05 16:59:48', '2016-06-05 16:59:50', 0, 991976, 4, 3, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `categorias`
--

CREATE TABLE `categorias` (
  `id` int(10) NOT NULL,
  `nombre` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categorias`
--

INSERT INTO `categorias` (`id`, `nombre`) VALUES
(1, 'sapos Rellenos'),
(2, 'Helados'),
(4, 'Carnes'),
(5, 'perros'),
(12, 'categoria Prueba 1'),
(13, 'categoria Prueba 1'),
(14, 'categoria Prueba 1'),
(15, 'categoria Prueba 1'),
(16, 'categoria Prueba 1'),
(17, 'categoria Prueba 1'),
(18, 'categoria Prueba 1'),
(19, 'categoria Prueba 1');

-- --------------------------------------------------------

--
-- Table structure for table `empleados`
--

CREATE TABLE `empleados` (
  `id` int(10) NOT NULL,
  `nombre` varchar(10) NOT NULL,
  `apellido` varchar(20) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `genero` varchar(20) DEFAULT NULL,
  `usuario` varchar(10) NOT NULL,
  `clave` varchar(10) NOT NULL,
  `admin` tinyint(1) DEFAULT NULL,
  `claveIngreso` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `empleados`
--

INSERT INTO `empleados` (`id`, `nombre`, `apellido`, `telefono`, `genero`, `usuario`, `clave`, `admin`, `claveIngreso`) VALUES
(110, 'david', 'david', '3113123232', 'on', 'admin', '1234', 0, '1234'),
(113, 'juan', 'juan', 'juan', 'on', 'juan', 'juan', 0, NULL),
(132, 'nombre2', 'apellido2', 'telefono2', 'genero2', 'usuario', 'cont2', 1, NULL),
(133, 'nombre', 'apellido', 'telefono', 'genero', 'usuario', 'pass', NULL, NULL),
(134, 'nombre', 'apellido', 'telefono', 'genero', 'usuario', 'pass', NULL, NULL),
(135, 'nombre', 'apellido', 'telefono', 'genero', 'usuario', 'pass', NULL, NULL),
(136, 'nombre', 'apellido', 'telefono', 'genero', 'usuario', 'pass', 1, NULL),
(137, 'nombre', 'apellido', 'telefono', 'genero', 'usuario', 'pass', 1, NULL),
(138, 'nombre', 'apellido', 'telefono', 'genero', 'usuario', 'pass', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `empl_atencion`
--

CREATE TABLE `empl_atencion` (
  `id` int(10) NOT NULL,
  `fk_empleado` int(10) DEFAULT NULL,
  `fk_aten_prod` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `empl_atencion`
--

INSERT INTO `empl_atencion` (`id`, `fk_empleado`, `fk_aten_prod`) VALUES
(8541, 110, 99737898),
(8542, 110, 99737899),
(8543, 110, 99737900),
(8544, 110, 99737901),
(8545, 110, 99737902),
(8546, 110, 99737903),
(8547, NULL, 99737904),
(8548, NULL, 99737905),
(8549, NULL, 99737906),
(8550, NULL, 99737907),
(8551, NULL, 99737908),
(8552, 110, 99737909),
(8553, 110, 99737910),
(8554, 110, 99737911),
(8555, 110, 99737912),
(8556, 110, 99737913),
(8557, 110, 99737914),
(8558, 110, 99737915),
(8559, 110, 99737916),
(8560, 110, 99737917),
(8561, 110, 99737918),
(8562, 110, 99737919),
(8563, 110, 99737920),
(8564, 110, 99737921);

-- --------------------------------------------------------

--
-- Table structure for table `estados_atencion`
--

CREATE TABLE `estados_atencion` (
  `id` int(10) NOT NULL,
  `descripcion` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `estados_atencion`
--

INSERT INTO `estados_atencion` (`id`, `descripcion`) VALUES
(1, 'pedido'),
(2, 'pago'),
(3, 'cortesia'),
(4, 'aplazado');

-- --------------------------------------------------------

--
-- Table structure for table `estados_prod`
--

CREATE TABLE `estados_prod` (
  `id` int(10) NOT NULL,
  `descripcion` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `estados_prod`
--

INSERT INTO `estados_prod` (`id`, `descripcion`) VALUES
(1, 'pedido'),
(2, 'preparando'),
(3, 'despachado');

-- --------------------------------------------------------

--
-- Table structure for table `horarios`
--

CREATE TABLE `horarios` (
  `id` int(10) NOT NULL,
  `fecha` datetime NOT NULL,
  `fk_empleado` int(10) NOT NULL,
  `fk_accion` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `horarios`
--

INSERT INTO `horarios` (`id`, `fecha`, `fk_empleado`, `fk_accion`) VALUES
(35, '2016-04-11 09:30:19', 113, 1);

-- --------------------------------------------------------

--
-- Table structure for table `inventarios`
--

CREATE TABLE `inventarios` (
  `id` int(10) NOT NULL,
  `fecha` datetime NOT NULL,
  `cantidad` int(10) NOT NULL,
  `proveedor` varchar(25) DEFAULT NULL,
  `costo` int(10) DEFAULT NULL,
  `descripcion` varchar(200) NOT NULL,
  `fk_producto` int(10) DEFAULT NULL,
  `fk_accion` int(10) DEFAULT NULL,
  `fk_empleado` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `mesas`
--

CREATE TABLE `mesas` (
  `id` int(10) NOT NULL,
  `descripcion` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mesas`
--

INSERT INTO `mesas` (`id`, `descripcion`) VALUES
(1, 'mesa 1 actualizada'),
(2, 'mesa 1 actualizada'),
(3, 'mesa 1 actualizada'),
(4, 'Mesa 4'),
(5, 'Mesa 5'),
(6, 'Mesa 6'),
(8, 'Mesa 8'),
(10, 'Barra 1'),
(48, 'mesa Prueba 1'),
(49, 'mesa Prueba 1'),
(50, 'mesa Prueba 1'),
(51, 'mesa Prueba 1'),
(52, 'mesa Prueba 1');

-- --------------------------------------------------------

--
-- Table structure for table `perfiles`
--

CREATE TABLE `perfiles` (
  `id` int(10) NOT NULL,
  `descripcion` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `perfiles`
--

INSERT INTO `perfiles` (`id`, `descripcion`) VALUES
(1, 'Cajero'),
(2, 'Mesero'),
(3, 'Cocinero'),
(4, 'inventario');

-- --------------------------------------------------------

--
-- Table structure for table `perfil_empleados`
--

CREATE TABLE `perfil_empleados` (
  `id` int(10) NOT NULL,
  `fk_perfil` int(10) NOT NULL,
  `fk_empleado` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `perfil_empleados`
--

INSERT INTO `perfil_empleados` (`id`, `fk_perfil`, `fk_empleado`) VALUES
(98, 2, 132),
(99, 2, 132),
(100, 2, 132),
(101, 2, 132),
(102, 2, 136),
(103, 3, 136),
(104, 4, 136),
(105, 1, 136),
(106, 2, 137),
(107, 3, 137),
(108, 4, 137),
(109, 1, 137),
(110, 2, 138),
(111, 3, 138),
(112, 4, 138),
(113, 1, 138);

-- --------------------------------------------------------

--
-- Table structure for table `productos`
--

CREATE TABLE `productos` (
  `id` int(10) NOT NULL,
  `nombre` varchar(25) NOT NULL,
  `valor` int(20) NOT NULL,
  `descripcion` varchar(300) NOT NULL,
  `imagen` varchar(30) DEFAULT NULL,
  `fk_categoria` int(10) DEFAULT NULL,
  `inventario` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `productos`
--

INSERT INTO `productos` (`id`, `nombre`, `valor`, `descripcion`, `imagen`, `fk_categoria`, `inventario`) VALUES
(1, 'nombre2', 20, 'descripcion2', NULL, 1, 1),
(2, 'arepa con carne', 5000, ' arepa,carne, chicharron, queso. ', NULL, 4, 0),
(3, 'cafe', 2000, 'cafe el mejor', NULL, 2, 0),
(4, 'helado', 10000, '  helado frio rico ', NULL, 1, 0),
(5, 'Costilla Asada', 12000, 'costilla asada al carbon con arepa y papa , salsa y gaseosa .', NULL, 4, 0),
(7, 'pepini', 24000, 'pepinio', NULL, 5, 0),
(9, 'helados crema', 12000, 'con crema', NULL, 2, 0),
(10, 'chococono', 1200, 'chococono ', NULL, 2, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `acciones`
--
ALTER TABLE `acciones`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `accion_inventarios`
--
ALTER TABLE `accion_inventarios`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `atenciones`
--
ALTER TABLE `atenciones`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_estado` (`fk_estado`),
  ADD KEY `fk_mesa` (`fk_mesa`),
  ADD KEY `fk_cajero` (`fk_cajero`);

--
-- Indexes for table `aten_prod`
--
ALTER TABLE `aten_prod`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_atencion` (`fk_atencion`,`fk_producto`),
  ADD KEY `fk_producto` (`fk_producto`),
  ADD KEY `fk_estadoProd` (`fk_estadoProd`),
  ADD KEY `fk_cocinero` (`fk_cocinero`);

--
-- Indexes for table `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `empleados`
--
ALTER TABLE `empleados`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `empl_atencion`
--
ALTER TABLE `empl_atencion`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_empleado` (`fk_empleado`),
  ADD KEY `fk_aten_prod` (`fk_aten_prod`),
  ADD KEY `fk_aten_prod_2` (`fk_aten_prod`);

--
-- Indexes for table `estados_atencion`
--
ALTER TABLE `estados_atencion`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `estados_prod`
--
ALTER TABLE `estados_prod`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `horarios`
--
ALTER TABLE `horarios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_empleado` (`fk_empleado`),
  ADD KEY `fk_accion` (`fk_accion`);

--
-- Indexes for table `inventarios`
--
ALTER TABLE `inventarios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_producto` (`fk_producto`),
  ADD KEY `fk_accion` (`fk_accion`),
  ADD KEY `fk_empleado` (`fk_empleado`);

--
-- Indexes for table `mesas`
--
ALTER TABLE `mesas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `perfiles`
--
ALTER TABLE `perfiles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `perfil_empleados`
--
ALTER TABLE `perfil_empleados`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_perfil` (`fk_perfil`),
  ADD KEY `fk_empleado` (`fk_empleado`);

--
-- Indexes for table `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_categoria` (`fk_categoria`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `acciones`
--
ALTER TABLE `acciones`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `accion_inventarios`
--
ALTER TABLE `accion_inventarios`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `atenciones`
--
ALTER TABLE `atenciones`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=991977;
--
-- AUTO_INCREMENT for table `aten_prod`
--
ALTER TABLE `aten_prod`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=99737922;
--
-- AUTO_INCREMENT for table `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `empleados`
--
ALTER TABLE `empleados`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=139;
--
-- AUTO_INCREMENT for table `empl_atencion`
--
ALTER TABLE `empl_atencion`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8565;
--
-- AUTO_INCREMENT for table `estados_atencion`
--
ALTER TABLE `estados_atencion`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `estados_prod`
--
ALTER TABLE `estados_prod`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `horarios`
--
ALTER TABLE `horarios`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT for table `inventarios`
--
ALTER TABLE `inventarios`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `mesas`
--
ALTER TABLE `mesas`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;
--
-- AUTO_INCREMENT for table `perfiles`
--
ALTER TABLE `perfiles`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `perfil_empleados`
--
ALTER TABLE `perfil_empleados`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=114;
--
-- AUTO_INCREMENT for table `productos`
--
ALTER TABLE `productos`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `atenciones`
--
ALTER TABLE `atenciones`
  ADD CONSTRAINT `atenciones_ibfk_2` FOREIGN KEY (`fk_mesa`) REFERENCES `mesas` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  ADD CONSTRAINT `atenciones_ibfk_3` FOREIGN KEY (`fk_estado`) REFERENCES `estados_atencion` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  ADD CONSTRAINT `atenciones_ibfk_4` FOREIGN KEY (`fk_cajero`) REFERENCES `empleados` (`id`) ON DELETE SET NULL ON UPDATE SET NULL;

--
-- Constraints for table `aten_prod`
--
ALTER TABLE `aten_prod`
  ADD CONSTRAINT `aten_prod_ibfk_1` FOREIGN KEY (`fk_atencion`) REFERENCES `atenciones` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  ADD CONSTRAINT `aten_prod_ibfk_2` FOREIGN KEY (`fk_producto`) REFERENCES `productos` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  ADD CONSTRAINT `aten_prod_ibfk_3` FOREIGN KEY (`fk_estadoProd`) REFERENCES `estados_prod` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  ADD CONSTRAINT `aten_prod_ibfk_4` FOREIGN KEY (`fk_cocinero`) REFERENCES `empleados` (`id`) ON DELETE SET NULL ON UPDATE SET NULL;

--
-- Constraints for table `empl_atencion`
--
ALTER TABLE `empl_atencion`
  ADD CONSTRAINT `empl_atencion_ibfk_1` FOREIGN KEY (`fk_empleado`) REFERENCES `empleados` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  ADD CONSTRAINT `empl_atencion_ibfk_2` FOREIGN KEY (`fk_aten_prod`) REFERENCES `aten_prod` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `horarios`
--
ALTER TABLE `horarios`
  ADD CONSTRAINT `horarios_ibfk_1` FOREIGN KEY (`fk_empleado`) REFERENCES `empleados` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `horarios_ibfk_2` FOREIGN KEY (`fk_accion`) REFERENCES `acciones` (`id`) ON DELETE SET NULL ON UPDATE SET NULL;

--
-- Constraints for table `perfil_empleados`
--
ALTER TABLE `perfil_empleados`
  ADD CONSTRAINT `perfil_empleados_ibfk_1` FOREIGN KEY (`fk_empleado`) REFERENCES `empleados` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `perfil_empleados_ibfk_2` FOREIGN KEY (`fk_perfil`) REFERENCES `perfiles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `productos`
--
ALTER TABLE `productos`
  ADD CONSTRAINT `productos_ibfk_1` FOREIGN KEY (`fk_categoria`) REFERENCES `categorias` (`id`) ON DELETE SET NULL ON UPDATE SET NULL;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
