        <!-- footer content -->
        <footer>
          <div class="copyright-info">
            <p class="pull-right">Mantil  © Todos los derechos reservados.</a>
            </p>
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->